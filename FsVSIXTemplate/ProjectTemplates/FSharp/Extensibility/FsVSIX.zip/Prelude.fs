﻿namespace $safeprojectname$

open System
open System.Collections.Generic

[<AutoOpen>]
module Prelude =

    ()